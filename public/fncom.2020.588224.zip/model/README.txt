Prerequisites:
Your computer must have not less than 16Gb RAM.
Your computer must have a java virtual machine, version 1.8 or higher. You can check this by typing the following command line:

java -version

To install java on Linux systems, follow the instructions at https://openjdk.java.net/install/
For installation on a Mac, use brew or macports package managers (for OpenJDK), or install Oracle JVM from https://www.java.com/en/download/mac_download.jsp



Running instruction:
1. Unzip the bcnnm.zip archive to any convenient directory.
2. In the command line, go to the directory containing the unpacked files.
3. Run the run.sh script:
./run.sh 



Results of the simulation will be available in model's subdirectory results.
It will contain next files: 
Individual.xml - snapshot of spatial objects and factor concentrations
AxonLength.csv - axon lengths for each neuron
SpaceSnapshot.csv - axon coordinates
Movements.csv - simulation event log
